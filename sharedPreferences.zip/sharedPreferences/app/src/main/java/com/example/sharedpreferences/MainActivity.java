package com.example.sharedpreferences;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText user;
    EditText password;
    Button signup_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Handle window insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize views AFTER setContentView
        user = findViewById(R.id.edittext_username);
        password = findViewById(R.id.edittext_password);
        signup_button = findViewById(R.id.button_signup);

        // Save default credentials
        SharedPreferences sharedPref = getSharedPreferences("sharedPreferences", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("username", "admin");
        editor.putString("password", "123");
        editor.apply();

        signup_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String uname = user.getText().toString().trim();
                String pwd = password.getText().toString().trim();

                // Get saved credentials
                SharedPreferences pref = getSharedPreferences("sharedPreferences", Context.MODE_PRIVATE);
                String savedUsername = pref.getString("username", null);
                String savedPassword = pref.getString("password", null);

                // Check if entered credentials match saved ones
                if (savedUsername != null && savedPassword != null) {
                    if (uname.equals(savedUsername) && pwd.equals(savedPassword)) {
                        Toast.makeText(MainActivity.this, "sign up successfull", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity.this, dashboard.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(MainActivity.this, "Incorrect username or password", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "No stored credentials found", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
